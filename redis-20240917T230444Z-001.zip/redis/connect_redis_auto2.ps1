# Função para verificar se o Azure CLI está logado
function Verify-AzLogin {
    try {
        $context = az account show 2>&1
        if ($context -match "az login") {
            Write-Host "Realizando login no Azure..."
            az login
        }
    } catch {
        Write-Error "Erro ao verificar ou realizar login no Azure: $_"
        exit
    }
}

Verify-AzLogin

# Função para baixar e extrair a DLL do StackExchange.Redis
function Install-StackExchangeRedis {
    $nugetUrl = "https://www.nuget.org/api/v2/package/StackExchange.Redis"
    $tempPath = [System.IO.Path]::GetTempPath()
    $nugetFile = Join-Path -Path $tempPath -ChildPath "StackExchange.Redis.nupkg"
    $dllFolder = Join-Path -Path $tempPath -ChildPath "StackExchange.Redis"

    # Baixar o pacote NuGet
    Write-Host "Baixando StackExchange.Redis..."
    Invoke-WebRequest -Uri $nugetUrl -OutFile $nugetFile

    # Extrair o pacote NuGet
    Write-Host "Extraindo StackExchange.Redis..."
    Expand-Archive -Path $nugetFile -DestinationPath $dllFolder -Force

    # Encontrar o caminho da DLL
    $dllPath = Get-ChildItem -Path $dllFolder -Filter "StackExchange.Redis.dll" -Recurse | Select-Object -First 1 -ExpandProperty FullName
    if (-not $dllPath) {
        Write-Error "DLL StackExchange.Redis não encontrada após a extração."
        exit
    }
    Write-Host "DLL StackExchange.Redis encontrada em: $dllPath"

    return $dllPath
}

# Carregar a DLL do StackExchange.Redis
$dllPath = Install-StackExchangeRedis
if (Test-Path -Path $dllPath) {
    try {
        Add-Type -Path $dllPath
    } catch {
        Write-Error "Erro ao carregar a DLL: $_"
        exit
    }
} else {
    Write-Error "DLL não encontrada no caminho: $dllPath"
    exit
} 
   <# Instalar e carregar a DLL do StackExchange.Redis
    $dllPath = Install-StackExchangeRedis
    
    # Verifica se o arquivo existe antes de tentar carregá-lo
    if (Test-Path -Path $dllPath) {
        try {
            [System.Reflection.Assembly]::LoadFrom($dllPath)
        } catch {
            Write-Error "Erro ao carregar a DLL: $_"
            exit
        }
    } else {
        Write-Error "DLL não encontrada no caminho: $dllPath"
        exit
    } #>
    
    # Listar as subscriptions
    function Select-Subscription {
        $global:subscriptions = az account list --output json | ConvertFrom-Json
        Write-Host "`nSubscriptions disponiveis:"
        for ($i = 0; $i -lt $global:subscriptions.Length; $i++) {
            Write-Host -ForegroundColor Yellow "[$i] $($global:subscriptions[$i].name) - $($global:subscriptions[$i].id)"
        }
        while ($true) {
            $selectedSubscriptionIndex = Read-Host "Digite o numero da subscription que deseja usar"
            if ($selectedSubscriptionIndex -match '^\d+$' -and $selectedSubscriptionIndex -ge 0 -and $selectedSubscriptionIndex -lt $global:subscriptions.Length) {
                $selectedSubscriptionId = $global:subscriptions[$selectedSubscriptionIndex].id
                az account set --subscription $selectedSubscriptionId
                return
            } else {
                Write-Host "Selecao invalida. Tente novamente." -ForegroundColor Red
            }
        }
    }
    
Select-Subscription

# Listar as instâncias do Redis
function Select-RedisInstance {
    $redisInstances = az redis list --output json | ConvertFrom-Json
    Write-Host "`nInstancias Redis disponiveis:"
    for ($i = 0; $i -lt $redisInstances.Length; $i++) {
        Write-Host -ForegroundColor Yellow "[$i] $($redisInstances[$i].name) - $($redisInstances[$i].hostname)"
    }

    while ($true) {
        $selectedRedisIndex = Read-Host "Digite o numero da instancia do Redis para conectar"
        if ($selectedRedisIndex -match '^\d+$' -and $selectedRedisIndex -ge 0 -and $selectedRedisIndex -lt $redisInstances.Length) {
            return $redisInstances[$selectedRedisIndex]
        } else {
            Write-Host "Selecao invalida. Tente novamente." -ForegroundColor Red
        }
    }
}

$selectedRedis = Select-RedisInstance
$hostname = $selectedRedis.hostname
$resourceGroupName = $selectedRedis.resourceGroup
$redisKey = az redis list-keys --name $selectedRedis.name --resource-group $resourceGroupName --query primaryKey -o tsv

Write-Host "Instancia Redis selecionada: $($selectedRedis.name) (Hostname: $hostname)"

# Verificar a conectividade nas portas 6379 e 6380
function Test-RedisConnection {
    param (
        [string]$hostname,
        [int]$port
    )

    try {
        $connection = [System.Net.Sockets.TcpClient]::new($hostname, $port)
        if ($connection.Connected) {
            $connection.Close()
            return $true
        }
    } catch {
        return $false
    }
    return $false
}

$port = 6379
if (Test-RedisConnection -hostname $hostname -port 6380) {
    $port = 6380
}

Write-Host "Conectado ao Redis no host $hostname na porta $port"

# Função para executar comandos no Redis usando StackExchange.Redis
function Execute-RedisCommand {
    param (
        [string]$hostname,
        [int]$port,
        [string]$redisKey,
        [string]$command
    )

    try {
        $options = [StackExchange.Redis.ConfigurationOptions]::Parse("${hostname}:${port}")
        $options.Password = $redisKey
        $options.Ssl = $true
        $options.AllowAdmin = $true
        $connection = [StackExchange.Redis.ConnectionMultiplexer]::Connect($options)
        $db = $connection.GetDatabase()

        $commandParts = $command -split ' '
        $commandName = $commandParts[0].ToLower()
        $commandArgs = $commandParts[1..($commandParts.Length - 1)]

        switch ($commandName) {
            "ping" {
                $result = $db.Ping()
                Write-Host "Resposta do Redis: PONG"
            }
            "info" {
                $server = $connection.GetServer($hostname, $port)
                $result = $server.Info()
                foreach ($info in $result) {
                    foreach ($keyValuePair in $info) {
                        Write-Host "$($keyValuePair.Key): $($keyValuePair.Value)"
                    }
                }
            }
            "flushall" {
                $connection.GetServer($hostname, $port).FlushAllDatabases()
                Write-Host "Resposta do Redis: OK"
            }
            "flushdb" {
                $server = $connection.GetServer($hostname, $port)
                $server.FlushDatabase($db.Database) # Assumindo que $db é o objeto IDatabase correto
                Write-Host "Resposta do Redis: OK"
            }
            default {
                $result = $db.Execute($commandName, $commandArgs)
                if ($result.IsNull) {
                    Write-Host "Resposta do Redis: (nenhuma resposta)"
                } else {
                    Write-Host "Resposta do Redis: $($result.ToString())"
                }
            }
        }
    } catch {
        Write-Error "Erro ao executar o comando no Redis: $_"
    } finally {
        if ($null -ne $connection) {
            $connection.Close()
        }
    }
}
# Loop para comandos interativos
while ($true) {
    $command = Read-Host "Digite um comando para executar no Redis (ou 'exit' para sair)"
    if ($command -eq "exit") {
        break
    }
    Execute-RedisCommand -hostname $hostname -port $port -redisKey $redisKey -command $command
}

Write-Host "Desconectado do Redis."